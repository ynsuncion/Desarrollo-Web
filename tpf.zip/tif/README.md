# Sistema de Gestión de Pacientes, Terapeutas y Fichas - API RESTful Spring Boot

Aplicación web backend construida con **Spring Boot**, **Spring Data JPA**, **Hibernate** y **MySQL**, organizada en una arquitectura por capas (**Controller**, **Repository**, **Model**, **Service** y **DTO**). Expone una API JSON con operaciones CRUD completas para sus tres entidades (**Paciente**, **Terapeuta** y **Ficha** del paciente) y cumple de forma explícita con las cuatro reglas pedidas.

---

## 📋 Tabla de Contenidos
1. [Descripción General](#-descripción-general)
2. [Tecnologías Utilizadas](#-tecnologías-utilizadas)
3. [Estructura del Proyecto y Arquitectura en Capas](#-estructura-del-proyecto-y-arquitectura-en-capas)
4. [Las 4 Reglas Implementadas](#-las-4-reglas-implementadas)
5. [Modelo de Datos y Entidades](#-modelo-de-datos-y-entidades)
6. [Paso a Paso de Construcción del Proyecto](#-paso-a-paso-de-construcción-del-proyecto)
7. [Configuración de Base de Datos y Entorno](#-configuración-de-base-de-datos-y-entorno)
8. [Guía de Pruebas](#-guía-de-pruebas)
9. [Listado de Endpoints y Ejemplos cURL](#-listado-de-endpoints-y-ejemplos-curl)
10. [Manejo de Errores](#-manejo-de-errores)

---

## 🏥 Descripción General

El sistema gestiona el registro de pacientes y su seguimiento por parte de un equipo de terapeutas:

- **Pacientes**: datos personales y de contacto. Si el paciente es menor de edad, se registra una persona adulta responsable.
- **Terapeutas**: profesionales con matrícula y especialidad.
- **Fichas**: la ficha de cada paciente (una por paciente). Registra el terapeuta a cargo, la fecha de ingreso, el motivo de consulta, el diagnóstico y las observaciones, y se puede **cerrar** cuando el paciente recibe el alta. La respuesta calcula la etapa del tratamiento y genera alertas de seguimiento.

---

## 🛠 Tecnologías Utilizadas

- **Java**: 21
- **Framework**: Spring Boot 4.1.2
- **Persistencia**: Spring Data JPA & Hibernate ORM
- **Base de Datos**: MySQL (driver `mysql-connector-j`)
- **Validación**: Jakarta Validation (`spring-boot-starter-validation`)
- **Productividad**: Project Lombok
- **Gestor de Construcción**: Apache Maven (con Maven Wrapper `mvnw`)
- **Herramienta de Testing de API**: Bruno (archivos `.bru` con `http://localhost:8080`)
- **Testing Unitario**: JUnit 5 y Mockito

La configuración inicial del proyecto en Spring Initializr está en `configuracion-proyecto.jpg`.

---

## 🏛 Estructura del Proyecto y Arquitectura en Capas

```text
src/main/java/ar/edu/centro8/ps/tif/
├── TifApplication.java
├── config/
│   └── DataLoader.java              # Precarga de datos de prueba al iniciar
├── controller/         # Capa Controller: endpoints REST y códigos HTTP
│   ├── FichaController.java
│   ├── PacienteController.java
│   └── TerapeutaController.java
├── service/            # Capa Service: interfaces e implementaciones
│   ├── FichaService.java
│   ├── PacienteService.java
│   ├── TerapeutaService.java
│   └── impl/
│       ├── FichaServiceImpl.java      <-- Contiene la ÚNICA regla de negocio en Service
│       ├── PacienteServiceImpl.java
│       └── TerapeutaServiceImpl.java
├── repository/         # Capa Repository: interfaces Spring Data JPA
│   ├── FichaRepository.java
│   ├── PacienteRepository.java
│   └── TerapeutaRepository.java
├── model/              # Capa Model: entidades JPA
│   ├── Ficha.java                     <-- Contiene la regla de dominio
│   ├── Paciente.java
│   ├── Terapeuta.java
│   └── enums/
│       └── EstadoFicha.java
├── dto/                # Capa DTO: objetos de transferencia
│   ├── request/
│   │   ├── CerrarFichaRequestDTO.java
│   │   ├── FichaRequestDTO.java
│   │   ├── PacienteRequestDTO.java    <-- Contiene la regla de negocio en RequestDTO
│   │   └── TerapeutaRequestDTO.java
│   └── response/
│       ├── ErrorResponseDTO.java
│       ├── FichaResponseDTO.java      <-- Contiene la regla de negocio en ResponseDTO
│       ├── PacienteResponseDTO.java
│       └── TerapeutaResponseDTO.java
└── exception/          # Manejo centralizado de errores
    ├── BusinessException.java
    ├── DomainException.java
    ├── ResourceNotFoundException.java
    └── GlobalExceptionHandler.java
```

El flujo de una petición es: `Controller` (recibe y valida el `RequestDTO`) → `Service` (lógica de negocio y transacción) → `Repository` (acceso a MySQL) → `Model` (entidades). La respuesta vuelve armada como `ResponseDTO`: la API nunca expone las entidades directamente.

---

## 🎯 Las 4 Reglas Implementadas

Se implementó **una regla en cada lugar pedido**. Cada una está marcada en el código con un comentario `REGLA DE ...`.

### 1. Regla de Negocio en RequestDTO
- **Ubicación**: `dto/request/PacienteRequestDTO.java`
- **Mecanismo**: validación personalizada con `@AssertTrue` de Jakarta Validation.
- **Descripción**: todo paciente menor de 18 años debe registrarse con una persona adulta responsable (campo `responsable`). Para los mayores de edad el campo es opcional.
- **Código**:
```java
@AssertTrue(message = "Regla de Negocio en RequestDTO: Los pacientes menores de 18 años deben informar un responsable adulto.")
public boolean isResponsableInformadoSiEsMenor() {
    if (fechaNacimiento == null) return true; // Lo valida @NotNull
    int edad = Period.between(fechaNacimiento, LocalDate.now()).getYears();
    if (edad >= MAYORIA_DE_EDAD) return true;
    return responsable != null && !responsable.trim().isEmpty();
}
```
- **Respuesta ante infracción**: `HTTP 400 Bad Request`, antes de llegar al servicio.

### 2. Regla de Negocio en ResponseDTO
- **Ubicación**: `dto/response/FichaResponseDTO.java` (método `fromEntity`)
- **Descripción**: a partir de la fecha de ingreso (y de la de alta, si la ficha está cerrada), la respuesta calcula los **días en tratamiento**, clasifica la **etapa** y genera una **alerta de seguimiento**:

| Condición | `etapaTratamiento` | `alertaSeguimiento` |
|---|---|---|
| Ficha cerrada | `FINALIZADO` | Indica fecha y motivo de alta |
| Activa, menos de 30 días | `INICIAL` | Completar la evaluación inicial y definir el plan |
| Activa, de 30 a 179 días | `EN CURSO` | Seguimiento regular |
| Activa, 180 días o más | `PROLONGADO` | Revisar el plan con el equipo terapéutico |

- **Código**:
```java
LocalDate hasta = (ficha.getFechaAlta() != null) ? ficha.getFechaAlta() : LocalDate.now();
long dias = Math.max(0, ChronoUnit.DAYS.between(ficha.getFechaIngreso(), hasta));

if (ficha.getEstado() == EstadoFicha.CERRADA) { etapa = "FINALIZADO"; ... }
else if (dias < 30)  { etapa = "INICIAL"; ... }
else if (dias < 180) { etapa = "EN CURSO"; ... }
else                 { etapa = "PROLONGADO"; ... }
```
- Además, `PacienteResponseDTO` incluye la `edad` calculada. Es un dato derivado, no una regla de negocio.

### 3. Regla de Dominio en el Modelo (Entidad)
- **Ubicación**: `model/Ficha.java` (método `cerrar`)
- **Descripción**: la entidad `Ficha` protege su propio ciclo de vida. Solo se puede cerrar si:
  1. Está en estado `ACTIVA` (si ya está `CERRADA`, lanza `DomainException`).
  2. Se informa un motivo de alta no vacío.
  3. La fecha de alta no es anterior a la de ingreso ni posterior a hoy (si no se informa, se usa la fecha actual).
- **Código**:
```java
public void cerrar(LocalDate fechaAlta, String motivo) {
    if (this.estado == EstadoFicha.CERRADA) {
        throw new DomainException("Regla de Dominio: La ficha ya se encuentra CERRADA.");
    }
    if (motivo == null || motivo.trim().isEmpty()) {
        throw new DomainException("Regla de Dominio: Debe proporcionarse obligatoriamente un motivo de alta para cerrar la ficha.");
    }
    LocalDate alta = (fechaAlta != null) ? fechaAlta : LocalDate.now();
    if (this.fechaIngreso != null && alta.isBefore(this.fechaIngreso)) {
        throw new DomainException("Regla de Dominio: La fecha de alta (" + alta + ") no puede ser anterior a la fecha de ingreso (" + this.fechaIngreso + ").");
    }
    if (alta.isAfter(LocalDate.now())) {
        throw new DomainException("Regla de Dominio: La fecha de alta no puede ser posterior a la fecha actual.");
    }
    this.estado = EstadoFicha.CERRADA;
    this.fechaAlta = alta;
    this.motivoAlta = motivo.trim();
}
```
- **Respuesta ante infracción**: `HTTP 400 Bad Request` con el mensaje de dominio.

### 4. La Única Regla de Negocio en la Capa Service
- **Ubicación**: `service/impl/FichaServiceImpl.java` (método `validarCupoDelTerapeuta`)
- **Descripción**: un terapeuta no puede tener a su cargo más de **3 fichas activas** al mismo tiempo (constante `MAX_FICHAS_ACTIVAS_POR_TERAPEUTA`). Las fichas cerradas no cuentan. Se controla al crear una ficha y al reasignarla a otro terapeuta. Necesita consultar la base de datos, por eso vive en el Service y no en la entidad.
- **Declaración explícita**: es la **única** regla de negocio de la capa Service. Los servicios de `Paciente` y `Terapeuta` solo hacen CRUD con control de existencia y de datos únicos (DNI y matrícula).
- **Código**:
```java
private void validarCupoDelTerapeuta(Long terapeutaId, Long fichaIdExcluir) {
    long fichasActivas = (fichaIdExcluir == null)
            ? fichaRepository.countByTerapeutaIdAndEstado(terapeutaId, EstadoFicha.ACTIVA)
            : fichaRepository.countByTerapeutaIdAndEstadoAndIdNot(terapeutaId, EstadoFicha.ACTIVA, fichaIdExcluir);

    if (fichasActivas >= MAX_FICHAS_ACTIVAS_POR_TERAPEUTA) {
        throw new BusinessException("Regla de Negocio (Service): El terapeuta ya tiene " + fichasActivas
                + " fichas activas a su cargo (máximo permitido: " + MAX_FICHAS_ACTIVAS_POR_TERAPEUTA + ").");
    }
}
```
- **Respuesta ante infracción**: `HTTP 409 Conflict`.

---

## 🗄 Modelo de Datos y Entidades

```mermaid
erDiagram
    PACIENTE ||--o| FICHA : posee
    TERAPEUTA ||--o{ FICHA : "tiene a cargo"

    TERAPEUTA {
        bigint id PK
        varchar nombre
        varchar apellido
        varchar dni UK
        varchar matricula UK
        varchar especialidad
        varchar telefono
        varchar email
    }

    PACIENTE {
        bigint id PK
        varchar nombre
        varchar apellido
        varchar dni UK
        date fecha_nacimiento
        varchar telefono
        varchar email
        varchar obra_social
        varchar responsable
    }

    FICHA {
        bigint id PK
        bigint paciente_id FK,UK
        bigint terapeuta_id FK
        date fecha_ingreso
        varchar motivo_consulta
        varchar diagnostico
        text observaciones
        varchar estado
        date fecha_alta
        varchar motivo_alta
        datetime fecha_creacion
    }
```

- **Paciente 1 — 0..1 Ficha**: cada paciente tiene como máximo una ficha. Al eliminar un paciente se elimina también su ficha (cascada).
- **Terapeuta 1 — N Fichas**: un terapeuta puede tener varias fichas (hasta 3 activas). No se puede eliminar un terapeuta que tiene fichas asignadas (responde `409`).

---

## 🚀 Paso a Paso de Construcción del Proyecto

El proyecto se construyó a partir del esqueleto entregado (`pom.xml`, estructura por capas y colección Bruno), adaptando el dominio a **Paciente, Terapeuta y Ficha**.

1. **Revisión del esqueleto inicial**:
   - Spring Boot 4.1.2 sobre Java 21, group `ar.edu.centro8.ps`, artifact `tif` (ver `configuracion-proyecto.jpg`).
   - Dependencias del `pom.xml`: Spring Web, Data JPA, Validation, MySQL Driver, Lombok y DevTools.
   - El esqueleto ya traía la organización por capas (`dto/request`, `dto/response`, `service` con interfaz e `impl`), el manejo de excepciones y la colección Bruno.

2. **Definición del dominio**: se reemplazaron las entidades del esqueleto por **Paciente**, **Terapeuta** y **Ficha** (una ficha por paciente, a cargo de un terapeuta). Se eliminaron las clases que ya no se usan.

3. **Configuración de la base de datos**: en `src/main/resources/application.properties` se configuró MySQL (`jdbc:mysql://localhost:3306/tif_db`), `ddl-auto=update` y el log de sentencias SQL. Usuario y contraseña se pueden pasar por las variables `DB_USERNAME` y `DB_PASSWORD`.

4. **Capa de excepciones**: se conservaron `ResourceNotFoundException` (404), `BusinessException` (409) y `DomainException` (400) con el `GlobalExceptionHandler` y el `ErrorResponseDTO`. Se agregó el manejo de `DataIntegrityViolationException` (409).

5. **Capa Model (con la regla de dominio)**:
   - Enum `EstadoFicha` (`ACTIVA`, `CERRADA`).
   - Entidades `Terapeuta`, `Paciente` (con `responsable` y relación `OneToOne` con la ficha) y `Ficha` (relación `OneToOne` con paciente y `ManyToOne` con terapeuta).
   - **Regla de dominio**: método `Ficha.cerrar(fechaAlta, motivo)`.

6. **Capa DTO**:
   - Request: `TerapeutaRequestDTO`, `PacienteRequestDTO`, `FichaRequestDTO` y `CerrarFichaRequestDTO`, con las validaciones de Bean Validation.
   - **Regla de negocio en RequestDTO**: `@AssertTrue` en `PacienteRequestDTO` (menores con responsable).
   - Response: `TerapeutaResponseDTO`, `PacienteResponseDTO` y `FichaResponseDTO`, todos con el método `fromEntity`.
   - **Regla de negocio en ResponseDTO**: días, etapa y alerta de seguimiento en `FichaResponseDTO`.

7. **Capa Repository**: `TerapeutaRepository`, `PacienteRepository` y `FichaRepository` con query methods (búsqueda por DNI, matrícula, paciente y terapeuta, y conteo de fichas activas por terapeuta).

8. **Capa Service**: interfaces `TerapeutaService`, `PacienteService` y `FichaService`, con sus implementaciones en `service/impl`.
   - **Única regla de negocio en Service**: `validarCupoDelTerapeuta` en `FichaServiceImpl`.

9. **Capa Controller**: `TerapeutaController`, `PacienteController` y `FichaController`, con el CRUD completo (POST, GET, GET por ID, PUT, DELETE), los endpoints de consulta de fichas por paciente y por terapeuta, y el endpoint de acción `PUT /api/fichas/{id}/cerrar`.

10. **Precarga de datos**: `DataLoader` carga terapeutas, pacientes y fichas de ejemplo si la base está vacía. Los datos se diseñaron para poder probar las 4 reglas desde Bruno.

11. **Tests automatizados**: `ReglasNegocioYDominioTest` cubre las 4 reglas con 12 tests (3 de RequestDTO, 3 de ResponseDTO, 4 de dominio y 2 de Service). `TifApplicationTests` verifica que el contexto de Spring levanta (requiere MySQL en ejecución).

12. **Colección Bruno**: se rehízo la carpeta `bruno/` para el nuevo dominio, con URLs directas `http://localhost:8080` (sin variables) y un `assert` con el código HTTP esperado en cada request.

13. **Verificación**: ejecutar `./mvnw clean test`, iniciar la aplicación con `./mvnw spring-boot:run` y correr la colección completa de Bruno.

---

## ⚙ Configuración de Base de Datos y Entorno

### Requisitos
JDK 21, MySQL en ejecución en el puerto 3306 y Bruno (opcional, para las pruebas).

### Archivo `application.properties`
```properties
spring.application.name=tif
server.port=8080

spring.datasource.url=jdbc:mysql://localhost:3306/tif_db?createDatabaseIfNotExist=true&useSSL=false&allowPublicKeyRetrieval=true&serverTimezone=America/Argentina/Buenos_Aires
spring.datasource.username=${DB_USERNAME:root}
spring.datasource.password=${DB_PASSWORD:1234}
spring.datasource.driver-class-name=com.mysql.cj.jdbc.Driver

spring.jpa.hibernate.ddl-auto=update
spring.jpa.show-sql=true
spring.jpa.properties.hibernate.format_sql=true
spring.jpa.properties.hibernate.dialect=org.hibernate.dialect.MySQLDialect
```

> **Nota**: la base `tif_db` se crea sola si no existe. Para usar otro usuario o contraseña, editá el archivo o definí las variables de entorno `DB_USERNAME` y `DB_PASSWORD`.

### Datos de prueba (`DataLoader`)
Al iniciar con la base vacía se cargan estos datos (los ids dependen de que la base esté vacía):

| Entidad | Id | Detalle |
|---|---|---|
| Terapeuta | 1, 2, 3 | Rossi, Gómez y Benítez |
| Paciente | 1 a 6 | El paciente 3 es menor y tiene responsable |
| Ficha 1 | paciente 1, terapeuta 1 | Activa, 10 días (etapa `INICIAL`) |
| Ficha 2 | paciente 2, terapeuta 1 | Activa, 90 días (etapa `EN CURSO`) |
| Ficha 3 | paciente 3, terapeuta 1 | Activa, 200 días (etapa `PROLONGADO`) |
| Ficha 4 | paciente 5, terapeuta 2 | Cerrada (etapa `FINALIZADO`) |

El terapeuta 1 queda con el cupo completo (3 fichas activas). Los pacientes 4 y 6 no tienen ficha.

Para volver a cargar los datos desde cero, borrá la base: `DROP DATABASE tif_db;`.

---

## 🧪 Guía de Pruebas

### Colección Bruno
En Bruno: **Open Collection** y elegir la carpeta `bruno/`. No requiere variables de entorno: todas las peticiones apuntan a `http://localhost:8080`.

Cada request tiene un `assert` con el código HTTP esperado. Para correr todo junto, clic derecho sobre la colección y **Run**. Con la base recién cargada por el `DataLoader`, las carpetas funcionan en orden, porque las pruebas usan ids que dependen de los pasos anteriores.

| Carpeta | Requests | Esperado |
|---|---|---|
| `1_Terapeutas/` | Crear (queda con id 4), Listar, Obtener por ID, Actualizar, Eliminar | 201, 200, 200, 200, 204 |
| `2_Pacientes/` | Crear (queda con id 7), Listar, Obtener por ID, Actualizar, Eliminar | 201, 200, 200, 200, 204 |
| `3_Fichas/` | Crear (queda con id 5), Listar, Obtener por ID, Obtener por Paciente ID, Obtener por Terapeuta ID, Actualizar, Cerrar, Eliminar | 201, 200, 200, 200, 200, 200, 200, 204 |
| `4_Pruebas_Reglas/` | Una por cada regla (ver abajo) | ver abajo |

#### Pruebas de las reglas (`4_Pruebas_Reglas/`)

| Request | Qué prueba | Esperado |
|---|---|---|
| Regla 1 - RequestDTO Menor Sin Responsable | Paciente nacido en 2014 sin `responsable` | **400** |
| Regla 1 - RequestDTO Menor Con Responsable | El mismo paciente con `responsable` | **201** |
| Regla 2 - ResponseDTO Etapa Prolongada y Alerta | `GET /api/fichas/3`: devuelve `diasEnTratamiento` 200, `etapaTratamiento` `PROLONGADO` y la alerta | **200** |
| Regla 3 - Dominio Modelo Alta Anterior al Ingreso | Cerrar la ficha 1 con `fechaAlta` 2020-01-01 | **400** |
| Regla 3 - Dominio Modelo Cerrar Ficha Ya Cerrada | Cerrar la ficha 4, que ya está cerrada | **400** |
| Regla 4 - Service Cupo Completo del Terapeuta | Crear una ficha para el paciente 6 con el terapeuta 1, que ya tiene 3 activas | **409** |

> El request "Menor Con Responsable" crea un paciente nuevo: si se corre dos veces seguidas, la segunda responde `400` por DNI duplicado.

### Pruebas Automatizadas con Maven
```bash
./mvnw clean test
```
- `ReglasNegocioYDominioTest`: 12 tests unitarios (con Mockito) de las 4 reglas.
- `TifApplicationTests`: levanta el contexto de Spring, por lo que necesita MySQL corriendo.

---

## 📡 Listado de Endpoints y Ejemplos cURL

#### Iniciar la aplicación
```bash
./mvnw spring-boot:run
```

#### 1. Terapeutas (`/api/terapeutas`)
| Método | Endpoint | Descripción |
|---|---|---|
| `POST` | `/api/terapeutas` | Registrar terapeuta (201) |
| `GET` | `/api/terapeutas` | Listar terapeutas |
| `GET` | `/api/terapeutas/{id}` | Obtener terapeuta por ID |
| `PUT` | `/api/terapeutas/{id}` | Actualizar terapeuta |
| `DELETE` | `/api/terapeutas/{id}` | Eliminar terapeuta (204; 409 si tiene fichas) |

```bash
curl -X POST http://localhost:8080/api/terapeutas \
  -H "Content-Type: application/json" \
  -d '{
    "nombre": "Sofía",
    "apellido": "Navarro",
    "dni": "33222111",
    "matricula": "MP-45678",
    "especialidad": "Terapia ocupacional",
    "telefono": "1166554433",
    "email": "sofia.navarro@ejemplo.com"
  }'
```

#### 2. Pacientes (`/api/pacientes`)
*(Aplica la regla de negocio del RequestDTO)*

| Método | Endpoint | Descripción |
|---|---|---|
| `POST` | `/api/pacientes` | Registrar paciente (201) |
| `GET` | `/api/pacientes` | Listar pacientes |
| `GET` | `/api/pacientes/{id}` | Obtener paciente por ID |
| `PUT` | `/api/pacientes/{id}` | Actualizar paciente |
| `DELETE` | `/api/pacientes/{id}` | Eliminar paciente y su ficha (204) |

```bash
curl -X POST http://localhost:8080/api/pacientes \
  -H "Content-Type: application/json" \
  -d '{
    "nombre": "Tomás",
    "apellido": "Medina",
    "dni": "50111222",
    "fechaNacimiento": "2014-05-10",
    "telefono": "1133445566",
    "email": "familia.medina@ejemplo.com",
    "responsable": "Laura Medina (madre)"
  }'
```

#### 3. Fichas (`/api/fichas`)
*(Aplica la regla de negocio del ResponseDTO, la de dominio y la única de Service)*

| Método | Endpoint | Descripción |
|---|---|---|
| `POST` | `/api/fichas` | Crear ficha (aplica la regla de Service) |
| `GET` | `/api/fichas` | Listar fichas |
| `GET` | `/api/fichas/{id}` | Obtener ficha por ID |
| `GET` | `/api/fichas/paciente/{pacienteId}` | Obtener la ficha de un paciente |
| `GET` | `/api/fichas/terapeuta/{terapeutaId}` | Listar las fichas de un terapeuta |
| `PUT` | `/api/fichas/{id}` | Actualizar ficha (la fecha de ingreso no se modifica) |
| `PUT` | `/api/fichas/{id}/cerrar` | Cerrar ficha con motivo de alta (regla de dominio) |
| `DELETE` | `/api/fichas/{id}` | Eliminar ficha (204) |

```bash
curl -X POST http://localhost:8080/api/fichas \
  -H "Content-Type: application/json" \
  -d '{
    "pacienteId": 4,
    "terapeutaId": 2,
    "motivoConsulta": "Evaluación inicial por derivación",
    "diagnostico": "En evaluación",
    "observaciones": "Primera entrevista pendiente."
  }'
```

*Cerrar una ficha (regla de dominio):*
```bash
curl -X PUT http://localhost:8080/api/fichas/5/cerrar \
  -H "Content-Type: application/json" \
  -d '{
    "motivo": "Alta por cumplimiento de los objetivos terapéuticos."
  }'
```
La fecha de alta es opcional (`"fechaAlta": "2026-11-20"`); si no se envía, se usa la fecha actual.

---

## ⚠ Manejo de Errores

Todas las respuestas de error tienen el mismo formato (`ErrorResponseDTO`):

```json
{
  "timestamp": "2026-11-25T10:15:30.123",
  "status": 409,
  "error": "Conflicto de Regla de Negocio (Service)",
  "message": "Regla de Negocio (Service): El terapeuta ya tiene 3 fichas activas a su cargo (máximo permitido: 3).",
  "path": "/api/fichas",
  "details": null
}
```

| Código | Cuándo |
|---|---|
| `400` | Datos inválidos (incluida la regla del RequestDTO, con el detalle en `details`), violación de una regla de dominio o dato único repetido (DNI, matrícula, ficha de un paciente que ya tiene una) |
| `404` | El recurso no existe |
| `409` | Se viola la regla de negocio de Service (cupo del terapeuta) o se intenta eliminar un registro con datos relacionados (por ejemplo, un terapeuta con fichas) |
| `500` | Error inesperado del servidor |

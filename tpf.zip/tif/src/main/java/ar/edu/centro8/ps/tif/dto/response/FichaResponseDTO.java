package ar.edu.centro8.ps.tif.dto.response;

import ar.edu.centro8.ps.tif.model.Ficha;
import ar.edu.centro8.ps.tif.model.enums.EstadoFicha;
import lombok.*;

import java.time.LocalDate;
import java.time.temporal.ChronoUnit;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class FichaResponseDTO {
    private Long id;
    private Long pacienteId;
    private String pacienteNombreCompleto;
    private String pacienteDni;
    private Long terapeutaId;
    private String terapeutaNombreCompleto;
    private String terapeutaEspecialidad;
    private LocalDate fechaIngreso;
    private String motivoConsulta;
    private String diagnostico;
    private String observaciones;
    private EstadoFicha estado;
    private LocalDate fechaAlta;
    private String motivoAlta;

    // =========================================================================
    // REGLA DE NEGOCIO EN EL RESPONSE DTO
    // =========================================================================
    private Long diasEnTratamiento;
    private String etapaTratamiento;
    private String alertaSeguimiento;

    /**
     * Regla de Negocio en ResponseDTO:
     * A partir de la fecha de ingreso (y de alta, si la ficha está cerrada), calcula en tiempo
     * de respuesta los días en tratamiento, clasifica la etapa del tratamiento
     * (INICIAL: menos de 30 días, EN CURSO: de 30 a 179 días, PROLONGADO: 180 días o más,
     * FINALIZADO: ficha cerrada) y genera una alerta de seguimiento para el equipo terapéutico.
     */
    public static FichaResponseDTO fromEntity(Ficha ficha) {
        if (ficha == null) return null;

        LocalDate hasta = (ficha.getFechaAlta() != null) ? ficha.getFechaAlta() : LocalDate.now();
        long dias = 0;
        if (ficha.getFechaIngreso() != null) {
            dias = Math.max(0, ChronoUnit.DAYS.between(ficha.getFechaIngreso(), hasta));
        }

        String etapa;
        String alerta;
        if (ficha.getEstado() == EstadoFicha.CERRADA) {
            etapa = "FINALIZADO";
            alerta = "Ficha cerrada el " + ficha.getFechaAlta() + ". Motivo de alta: " + ficha.getMotivoAlta() + ".";
        } else if (dias < 30) {
            etapa = "INICIAL";
            alerta = "Ficha reciente: completar la evaluación inicial y definir el plan de tratamiento.";
        } else if (dias < 180) {
            etapa = "EN CURSO";
            alerta = "Seguimiento regular dentro de los plazos esperados.";
        } else {
            etapa = "PROLONGADO";
            alerta = "Atención: tratamiento prolongado (180 días o más). Revisar el plan con el equipo terapéutico.";
        }

        return FichaResponseDTO.builder()
                .id(ficha.getId())
                .pacienteId(ficha.getPaciente() != null ? ficha.getPaciente().getId() : null)
                .pacienteNombreCompleto(ficha.getPaciente() != null ? ficha.getPaciente().getApellido() + ", " + ficha.getPaciente().getNombre() : null)
                .pacienteDni(ficha.getPaciente() != null ? ficha.getPaciente().getDni() : null)
                .terapeutaId(ficha.getTerapeuta() != null ? ficha.getTerapeuta().getId() : null)
                .terapeutaNombreCompleto(ficha.getTerapeuta() != null ? ficha.getTerapeuta().getApellido() + ", " + ficha.getTerapeuta().getNombre() : null)
                .terapeutaEspecialidad(ficha.getTerapeuta() != null ? ficha.getTerapeuta().getEspecialidad() : null)
                .fechaIngreso(ficha.getFechaIngreso())
                .motivoConsulta(ficha.getMotivoConsulta())
                .diagnostico(ficha.getDiagnostico())
                .observaciones(ficha.getObservaciones())
                .estado(ficha.getEstado())
                .fechaAlta(ficha.getFechaAlta())
                .motivoAlta(ficha.getMotivoAlta())
                .diasEnTratamiento(dias)
                .etapaTratamiento(etapa)
                .alertaSeguimiento(alerta)
                .build();
    }
}

package ar.edu.centro8.ps.tif.dto.request;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.*;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class FichaRequestDTO {

    @NotNull(message = "El ID del paciente es obligatorio")
    private Long pacienteId;

    @NotNull(message = "El ID del terapeuta es obligatorio")
    private Long terapeutaId;

    @NotBlank(message = "El motivo de consulta es obligatorio")
    @Size(min = 3, max = 255, message = "El motivo de consulta debe tener entre 3 y 255 caracteres")
    private String motivoConsulta;

    @Size(max = 255, message = "El diagnóstico no puede exceder los 255 caracteres")
    private String diagnostico;

    private String observaciones;
}

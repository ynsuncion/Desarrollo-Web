package ar.edu.centro8.ps.tif.model;

import jakarta.persistence.*;
import lombok.*;

@Entity
@Table(name = "terapeutas")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Terapeuta {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false, length = 100)
    private String nombre;

    @Column(nullable = false, length = 100)
    private String apellido;

    @Column(nullable = false, unique = true, length = 20)
    private String dni;

    @Column(nullable = false, unique = true, length = 30)
    private String matricula;

    @Column(nullable = false, length = 100)
    private String especialidad;

    @Column(length = 30)
    private String telefono;

    @Column(nullable = false, length = 120)
    private String email;
}

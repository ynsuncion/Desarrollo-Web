package ar.edu.centro8.ps.tif.service.impl;

import ar.edu.centro8.ps.tif.dto.request.TerapeutaRequestDTO;
import ar.edu.centro8.ps.tif.dto.response.TerapeutaResponseDTO;
import ar.edu.centro8.ps.tif.exception.ResourceNotFoundException;
import ar.edu.centro8.ps.tif.model.Terapeuta;
import ar.edu.centro8.ps.tif.repository.TerapeutaRepository;
import ar.edu.centro8.ps.tif.service.TerapeutaService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class TerapeutaServiceImpl implements TerapeutaService {

    private final TerapeutaRepository terapeutaRepository;

    @Override
    @Transactional
    public TerapeutaResponseDTO crear(TerapeutaRequestDTO dto) {
        if (terapeutaRepository.existsByDni(dto.getDni())) {
            throw new IllegalArgumentException("Ya existe un terapeuta registrado con el DNI: " + dto.getDni());
        }
        if (terapeutaRepository.existsByMatricula(dto.getMatricula())) {
            throw new IllegalArgumentException("Ya existe un terapeuta registrado con la matrícula: " + dto.getMatricula());
        }

        Terapeuta terapeuta = Terapeuta.builder()
                .nombre(dto.getNombre())
                .apellido(dto.getApellido())
                .dni(dto.getDni())
                .matricula(dto.getMatricula())
                .especialidad(dto.getEspecialidad())
                .telefono(dto.getTelefono())
                .email(dto.getEmail())
                .build();

        return TerapeutaResponseDTO.fromEntity(terapeutaRepository.save(terapeuta));
    }

    @Override
    @Transactional(readOnly = true)
    public List<TerapeutaResponseDTO> obtenerTodos() {
        return terapeutaRepository.findAll().stream()
                .map(TerapeutaResponseDTO::fromEntity)
                .collect(Collectors.toList());
    }

    @Override
    @Transactional(readOnly = true)
    public TerapeutaResponseDTO obtenerPorId(Long id) {
        return TerapeutaResponseDTO.fromEntity(buscar(id));
    }

    @Override
    @Transactional
    public TerapeutaResponseDTO actualizar(Long id, TerapeutaRequestDTO dto) {
        Terapeuta terapeuta = buscar(id);

        if (terapeutaRepository.existsByDniAndIdNot(dto.getDni(), id)) {
            throw new IllegalArgumentException("Ya existe otro terapeuta registrado con el DNI: " + dto.getDni());
        }
        if (terapeutaRepository.existsByMatriculaAndIdNot(dto.getMatricula(), id)) {
            throw new IllegalArgumentException("Ya existe otro terapeuta registrado con la matrícula: " + dto.getMatricula());
        }

        terapeuta.setNombre(dto.getNombre());
        terapeuta.setApellido(dto.getApellido());
        terapeuta.setDni(dto.getDni());
        terapeuta.setMatricula(dto.getMatricula());
        terapeuta.setEspecialidad(dto.getEspecialidad());
        terapeuta.setTelefono(dto.getTelefono());
        terapeuta.setEmail(dto.getEmail());

        return TerapeutaResponseDTO.fromEntity(terapeutaRepository.save(terapeuta));
    }

    @Override
    @Transactional
    public void eliminar(Long id) {
        Terapeuta terapeuta = buscar(id);
        terapeutaRepository.delete(terapeuta);
        // flush: fuerza el DELETE acá para que, si el terapeuta tiene fichas asignadas,
        // el error de integridad se produzca dentro del método y responda HTTP 409.
        terapeutaRepository.flush();
    }

    private Terapeuta buscar(Long id) {
        return terapeutaRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Terapeuta no encontrado con ID: " + id));
    }
}

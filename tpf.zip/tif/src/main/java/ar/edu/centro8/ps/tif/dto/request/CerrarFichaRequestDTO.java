package ar.edu.centro8.ps.tif.dto.request;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;
import lombok.*;

import java.time.LocalDate;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class CerrarFichaRequestDTO {

    /** Opcional: si no se informa, se toma la fecha actual. */
    private LocalDate fechaAlta;

    @NotBlank(message = "El motivo de alta es obligatorio")
    @Size(min = 5, max = 255, message = "El motivo de alta debe tener entre 5 y 255 caracteres")
    private String motivo;
}

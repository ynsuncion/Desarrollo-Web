package ar.edu.centro8.ps.tif.dto.response;

import ar.edu.centro8.ps.tif.model.Paciente;
import lombok.*;

import java.time.LocalDate;
import java.time.Period;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class PacienteResponseDTO {
    private Long id;
    private String nombre;
    private String apellido;
    private String nombreCompleto;
    private String dni;
    private LocalDate fechaNacimiento;
    private Integer edad;
    private String telefono;
    private String email;
    private String obraSocial;
    private String responsable;
    private Boolean tieneFicha;

    public static PacienteResponseDTO fromEntity(Paciente paciente) {
        if (paciente == null) return null;

        Integer edadCalculada = null;
        if (paciente.getFechaNacimiento() != null) {
            edadCalculada = Period.between(paciente.getFechaNacimiento(), LocalDate.now()).getYears();
        }

        return PacienteResponseDTO.builder()
                .id(paciente.getId())
                .nombre(paciente.getNombre())
                .apellido(paciente.getApellido())
                .nombreCompleto(paciente.getApellido() + ", " + paciente.getNombre())
                .dni(paciente.getDni())
                .fechaNacimiento(paciente.getFechaNacimiento())
                .edad(edadCalculada)
                .telefono(paciente.getTelefono())
                .email(paciente.getEmail())
                .obraSocial(paciente.getObraSocial())
                .responsable(paciente.getResponsable())
                .tieneFicha(paciente.getFicha() != null)
                .build();
    }
}

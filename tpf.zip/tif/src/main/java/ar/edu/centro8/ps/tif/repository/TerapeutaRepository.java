package ar.edu.centro8.ps.tif.repository;

import ar.edu.centro8.ps.tif.model.Terapeuta;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface TerapeutaRepository extends JpaRepository<Terapeuta, Long> {

    boolean existsByDni(String dni);

    boolean existsByMatricula(String matricula);

    boolean existsByDniAndIdNot(String dni, Long id);

    boolean existsByMatriculaAndIdNot(String matricula, Long id);

    Optional<Terapeuta> findByDni(String dni);

    Optional<Terapeuta> findByMatricula(String matricula);

    List<Terapeuta> findByEspecialidadIgnoreCase(String especialidad);
}

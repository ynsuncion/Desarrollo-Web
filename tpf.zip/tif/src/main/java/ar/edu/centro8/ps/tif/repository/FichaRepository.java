package ar.edu.centro8.ps.tif.repository;

import ar.edu.centro8.ps.tif.model.Ficha;
import ar.edu.centro8.ps.tif.model.enums.EstadoFicha;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface FichaRepository extends JpaRepository<Ficha, Long> {

    Optional<Ficha> findByPacienteId(Long pacienteId);

    List<Ficha> findByTerapeutaId(Long terapeutaId);

    boolean existsByPacienteId(Long pacienteId);

    /* ¿Existe otra ficha para este paciente, distinta de la actual? */
    boolean existsByPacienteIdAndIdNot(Long pacienteId, Long id);

    // =========================================================================
    // QUERY METHODS UTILIZADOS POR LA REGLA DE NEGOCIO EN SERVICE
    // =========================================================================
    long countByTerapeutaIdAndEstado(Long terapeutaId, EstadoFicha estado);

    long countByTerapeutaIdAndEstadoAndIdNot(Long terapeutaId, EstadoFicha estado, Long id);
}

package ar.edu.centro8.ps.tif.service.impl;

import ar.edu.centro8.ps.tif.dto.request.CerrarFichaRequestDTO;
import ar.edu.centro8.ps.tif.dto.request.FichaRequestDTO;
import ar.edu.centro8.ps.tif.dto.response.FichaResponseDTO;
import ar.edu.centro8.ps.tif.exception.BusinessException;
import ar.edu.centro8.ps.tif.exception.ResourceNotFoundException;
import ar.edu.centro8.ps.tif.model.Ficha;
import ar.edu.centro8.ps.tif.model.Paciente;
import ar.edu.centro8.ps.tif.model.Terapeuta;
import ar.edu.centro8.ps.tif.model.enums.EstadoFicha;
import ar.edu.centro8.ps.tif.repository.FichaRepository;
import ar.edu.centro8.ps.tif.repository.PacienteRepository;
import ar.edu.centro8.ps.tif.repository.TerapeutaRepository;
import ar.edu.centro8.ps.tif.service.FichaService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class FichaServiceImpl implements FichaService {

    /** Cantidad máxima de fichas ACTIVAS que puede tener a cargo un terapeuta. */
    public static final int MAX_FICHAS_ACTIVAS_POR_TERAPEUTA = 3;

    private final FichaRepository fichaRepository;
    private final PacienteRepository pacienteRepository;
    private final TerapeutaRepository terapeutaRepository;

    // =========================================================================
    // ÚNICA REGLA DE NEGOCIO EN LA CAPA SERVICE
    // =========================================================================
    /**
     * REGLA DE NEGOCIO EN SERVICE:
     * Control de cupo de pacientes por terapeuta.
     * Un terapeuta no puede tener a su cargo más de MAX_FICHAS_ACTIVAS_POR_TERAPEUTA
     * fichas en estado ACTIVA al mismo tiempo. Las fichas CERRADAS no cuentan.
     * Necesita consultar la base de datos, por eso vive en el Service y no en la entidad.
     */
    private void validarCupoDelTerapeuta(Long terapeutaId, Long fichaIdExcluir) {
        long fichasActivas;
        if (fichaIdExcluir == null) {
            fichasActivas = fichaRepository.countByTerapeutaIdAndEstado(terapeutaId, EstadoFicha.ACTIVA);
        } else {
            fichasActivas = fichaRepository.countByTerapeutaIdAndEstadoAndIdNot(terapeutaId, EstadoFicha.ACTIVA, fichaIdExcluir);
        }

        if (fichasActivas >= MAX_FICHAS_ACTIVAS_POR_TERAPEUTA) {
            throw new BusinessException("Regla de Negocio (Service): El terapeuta ya tiene " + fichasActivas
                    + " fichas activas a su cargo (máximo permitido: " + MAX_FICHAS_ACTIVAS_POR_TERAPEUTA + ").");
        }
    }

    @Override
    @Transactional
    public FichaResponseDTO crear(FichaRequestDTO dto) {
        Paciente paciente = buscarPaciente(dto.getPacienteId());
        Terapeuta terapeuta = buscarTerapeuta(dto.getTerapeutaId());

        if (fichaRepository.existsByPacienteId(dto.getPacienteId())) {
            throw new IllegalArgumentException("El paciente con ID " + dto.getPacienteId() + " ya posee una ficha registrada.");
        }

        // Ejecución de la ÚNICA regla de negocio en Service
        validarCupoDelTerapeuta(dto.getTerapeutaId(), null);

        Ficha ficha = Ficha.builder()
                .paciente(paciente)
                .terapeuta(terapeuta)
                .fechaIngreso(LocalDate.now())
                .motivoConsulta(dto.getMotivoConsulta())
                .diagnostico(dto.getDiagnostico())
                .observaciones(dto.getObservaciones())
                .estado(EstadoFicha.ACTIVA)
                .fechaCreacion(LocalDateTime.now())
                .build();

        return FichaResponseDTO.fromEntity(fichaRepository.save(ficha));
    }

    @Override
    @Transactional(readOnly = true)
    public List<FichaResponseDTO> obtenerTodas() {
        return fichaRepository.findAll().stream()
                .map(FichaResponseDTO::fromEntity)
                .collect(Collectors.toList());
    }

    @Override
    @Transactional(readOnly = true)
    public FichaResponseDTO obtenerPorId(Long id) {
        return FichaResponseDTO.fromEntity(buscar(id));
    }

    @Override
    @Transactional(readOnly = true)
    public FichaResponseDTO obtenerPorPacienteId(Long pacienteId) {
        Ficha ficha = fichaRepository.findByPacienteId(pacienteId)
                .orElseThrow(() -> new ResourceNotFoundException("No se encontró ficha para el paciente con ID: " + pacienteId));
        return FichaResponseDTO.fromEntity(ficha);
    }

    @Override
    @Transactional(readOnly = true)
    public List<FichaResponseDTO> obtenerPorTerapeutaId(Long terapeutaId) {
        if (!terapeutaRepository.existsById(terapeutaId)) {
            throw new ResourceNotFoundException("Terapeuta no encontrado con ID: " + terapeutaId);
        }
        return fichaRepository.findByTerapeutaId(terapeutaId).stream()
                .map(FichaResponseDTO::fromEntity)
                .collect(Collectors.toList());
    }

    @Override
    @Transactional
    public FichaResponseDTO actualizar(Long id, FichaRequestDTO dto) {
        Ficha ficha = buscar(id);

        if (!dto.getPacienteId().equals(ficha.getPaciente().getId())) {
            Paciente nuevoPaciente = buscarPaciente(dto.getPacienteId());
            if (fichaRepository.existsByPacienteIdAndIdNot(dto.getPacienteId(), id)) {
                throw new IllegalArgumentException("Ya existe una ficha registrada para el paciente ID: " + dto.getPacienteId());
            }
            ficha.setPaciente(nuevoPaciente);
        }

        if (!dto.getTerapeutaId().equals(ficha.getTerapeuta().getId())) {
            Terapeuta nuevoTerapeuta = buscarTerapeuta(dto.getTerapeutaId());
            if (ficha.getEstado() == EstadoFicha.ACTIVA) {
                // Ejecución de la regla de negocio de Service al reasignar la ficha
                validarCupoDelTerapeuta(dto.getTerapeutaId(), id);
            }
            ficha.setTerapeuta(nuevoTerapeuta);
        }

        ficha.setMotivoConsulta(dto.getMotivoConsulta());
        ficha.setDiagnostico(dto.getDiagnostico());
        ficha.setObservaciones(dto.getObservaciones());

        return FichaResponseDTO.fromEntity(fichaRepository.save(ficha));
    }

    @Override
    @Transactional
    public FichaResponseDTO cerrar(Long id, CerrarFichaRequestDTO dto) {
        Ficha ficha = buscar(id);

        // Dispara la regla de dominio encapsulada en la entidad Ficha
        ficha.cerrar(dto.getFechaAlta(), dto.getMotivo());

        return FichaResponseDTO.fromEntity(fichaRepository.save(ficha));
    }

    @Override
    @Transactional
    public void eliminar(Long id) {
        fichaRepository.delete(buscar(id));
    }

    private Ficha buscar(Long id) {
        return fichaRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Ficha no encontrada con ID: " + id));
    }

    private Paciente buscarPaciente(Long id) {
        return pacienteRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Paciente no encontrado con ID: " + id));
    }

    private Terapeuta buscarTerapeuta(Long id) {
        return terapeutaRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Terapeuta no encontrado con ID: " + id));
    }
}

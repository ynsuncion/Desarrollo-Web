package ar.edu.centro8.ps.tif.dto.response;

import ar.edu.centro8.ps.tif.model.Terapeuta;
import lombok.*;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class TerapeutaResponseDTO {
    private Long id;
    private String nombre;
    private String apellido;
    private String nombreCompleto;
    private String dni;
    private String matricula;
    private String especialidad;
    private String telefono;
    private String email;

    public static TerapeutaResponseDTO fromEntity(Terapeuta terapeuta) {
        if (terapeuta == null) return null;
        return TerapeutaResponseDTO.builder()
                .id(terapeuta.getId())
                .nombre(terapeuta.getNombre())
                .apellido(terapeuta.getApellido())
                .nombreCompleto(terapeuta.getApellido() + ", " + terapeuta.getNombre())
                .dni(terapeuta.getDni())
                .matricula(terapeuta.getMatricula())
                .especialidad(terapeuta.getEspecialidad())
                .telefono(terapeuta.getTelefono())
                .email(terapeuta.getEmail())
                .build();
    }
}

package ar.edu.centro8.ps.tif.controller;

import ar.edu.centro8.ps.tif.dto.request.TerapeutaRequestDTO;
import ar.edu.centro8.ps.tif.dto.response.TerapeutaResponseDTO;
import ar.edu.centro8.ps.tif.service.TerapeutaService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/terapeutas")
@RequiredArgsConstructor
@CrossOrigin(origins = "*")
public class TerapeutaController {

    private final TerapeutaService terapeutaService;

    @PostMapping
    public ResponseEntity<TerapeutaResponseDTO> crear(@Valid @RequestBody TerapeutaRequestDTO dto) {
        return ResponseEntity.status(HttpStatus.CREATED).body(terapeutaService.crear(dto));
    }

    @GetMapping
    public ResponseEntity<List<TerapeutaResponseDTO>> obtenerTodos() {
        return ResponseEntity.ok(terapeutaService.obtenerTodos());
    }

    @GetMapping("/{id}")
    public ResponseEntity<TerapeutaResponseDTO> obtenerPorId(@PathVariable Long id) {
        return ResponseEntity.ok(terapeutaService.obtenerPorId(id));
    }

    @PutMapping("/{id}")
    public ResponseEntity<TerapeutaResponseDTO> actualizar(
            @PathVariable Long id,
            @Valid @RequestBody TerapeutaRequestDTO dto) {
        return ResponseEntity.ok(terapeutaService.actualizar(id, dto));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> eliminar(@PathVariable Long id) {
        terapeutaService.eliminar(id);
        return ResponseEntity.noContent().build();
    }
}

package ar.edu.centro8.ps.tif.controller;

import ar.edu.centro8.ps.tif.dto.request.CerrarFichaRequestDTO;
import ar.edu.centro8.ps.tif.dto.request.FichaRequestDTO;
import ar.edu.centro8.ps.tif.dto.response.FichaResponseDTO;
import ar.edu.centro8.ps.tif.service.FichaService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/fichas")
@RequiredArgsConstructor
@CrossOrigin(origins = "*")
public class FichaController {

    private final FichaService fichaService;

    @PostMapping
    public ResponseEntity<FichaResponseDTO> crear(@Valid @RequestBody FichaRequestDTO dto) {
        return ResponseEntity.status(HttpStatus.CREATED).body(fichaService.crear(dto));
    }

    @GetMapping
    public ResponseEntity<List<FichaResponseDTO>> obtenerTodas() {
        return ResponseEntity.ok(fichaService.obtenerTodas());
    }

    @GetMapping("/{id}")
    public ResponseEntity<FichaResponseDTO> obtenerPorId(@PathVariable Long id) {
        return ResponseEntity.ok(fichaService.obtenerPorId(id));
    }

    @GetMapping("/paciente/{pacienteId}")
    public ResponseEntity<FichaResponseDTO> obtenerPorPacienteId(@PathVariable Long pacienteId) {
        return ResponseEntity.ok(fichaService.obtenerPorPacienteId(pacienteId));
    }

    @GetMapping("/terapeuta/{terapeutaId}")
    public ResponseEntity<List<FichaResponseDTO>> obtenerPorTerapeutaId(@PathVariable Long terapeutaId) {
        return ResponseEntity.ok(fichaService.obtenerPorTerapeutaId(terapeutaId));
    }

    @PutMapping("/{id}")
    public ResponseEntity<FichaResponseDTO> actualizar(
            @PathVariable Long id,
            @Valid @RequestBody FichaRequestDTO dto) {
        return ResponseEntity.ok(fichaService.actualizar(id, dto));
    }

    @PutMapping("/{id}/cerrar")
    public ResponseEntity<FichaResponseDTO> cerrar(
            @PathVariable Long id,
            @Valid @RequestBody CerrarFichaRequestDTO dto) {
        return ResponseEntity.ok(fichaService.cerrar(id, dto));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> eliminar(@PathVariable Long id) {
        fichaService.eliminar(id);
        return ResponseEntity.noContent().build();
    }
}

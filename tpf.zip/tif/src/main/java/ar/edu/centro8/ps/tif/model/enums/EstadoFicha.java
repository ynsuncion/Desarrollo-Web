package ar.edu.centro8.ps.tif.model.enums;

public enum EstadoFicha {
    ACTIVA,
    CERRADA
}

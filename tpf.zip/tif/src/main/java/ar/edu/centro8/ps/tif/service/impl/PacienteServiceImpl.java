package ar.edu.centro8.ps.tif.service.impl;

import ar.edu.centro8.ps.tif.dto.request.PacienteRequestDTO;
import ar.edu.centro8.ps.tif.dto.response.PacienteResponseDTO;
import ar.edu.centro8.ps.tif.exception.ResourceNotFoundException;
import ar.edu.centro8.ps.tif.model.Paciente;
import ar.edu.centro8.ps.tif.repository.PacienteRepository;
import ar.edu.centro8.ps.tif.service.PacienteService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class PacienteServiceImpl implements PacienteService {

    private final PacienteRepository pacienteRepository;

    @Override
    @Transactional
    public PacienteResponseDTO crear(PacienteRequestDTO dto) {
        if (pacienteRepository.existsByDni(dto.getDni())) {
            throw new IllegalArgumentException("Ya existe un paciente registrado con el DNI: " + dto.getDni());
        }

        Paciente paciente = Paciente.builder()
                .nombre(dto.getNombre())
                .apellido(dto.getApellido())
                .dni(dto.getDni())
                .fechaNacimiento(dto.getFechaNacimiento())
                .telefono(dto.getTelefono())
                .email(dto.getEmail())
                .obraSocial(dto.getObraSocial())
                .responsable(dto.getResponsable())
                .build();

        return PacienteResponseDTO.fromEntity(pacienteRepository.save(paciente));
    }

    @Override
    @Transactional(readOnly = true)
    public List<PacienteResponseDTO> obtenerTodos() {
        return pacienteRepository.findAll().stream()
                .map(PacienteResponseDTO::fromEntity)
                .collect(Collectors.toList());
    }

    @Override
    @Transactional(readOnly = true)
    public PacienteResponseDTO obtenerPorId(Long id) {
        return PacienteResponseDTO.fromEntity(buscar(id));
    }

    @Override
    @Transactional
    public PacienteResponseDTO actualizar(Long id, PacienteRequestDTO dto) {
        Paciente paciente = buscar(id);

        if (pacienteRepository.existsByDniAndIdNot(dto.getDni(), id)) {
            throw new IllegalArgumentException("Ya existe otro paciente registrado con el DNI: " + dto.getDni());
        }

        paciente.setNombre(dto.getNombre());
        paciente.setApellido(dto.getApellido());
        paciente.setDni(dto.getDni());
        paciente.setFechaNacimiento(dto.getFechaNacimiento());
        paciente.setTelefono(dto.getTelefono());
        paciente.setEmail(dto.getEmail());
        paciente.setObraSocial(dto.getObraSocial());
        paciente.setResponsable(dto.getResponsable());

        return PacienteResponseDTO.fromEntity(pacienteRepository.save(paciente));
    }

    @Override
    @Transactional
    public void eliminar(Long id) {
        // La ficha del paciente se elimina en cascada (CascadeType.ALL + orphanRemoval).
        pacienteRepository.delete(buscar(id));
    }

    private Paciente buscar(Long id) {
        return pacienteRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Paciente no encontrado con ID: " + id));
    }
}

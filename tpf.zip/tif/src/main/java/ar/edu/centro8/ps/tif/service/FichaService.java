package ar.edu.centro8.ps.tif.service;

import ar.edu.centro8.ps.tif.dto.request.CerrarFichaRequestDTO;
import ar.edu.centro8.ps.tif.dto.request.FichaRequestDTO;
import ar.edu.centro8.ps.tif.dto.response.FichaResponseDTO;

import java.util.List;

public interface FichaService {
    FichaResponseDTO crear(FichaRequestDTO dto);
    List<FichaResponseDTO> obtenerTodas();
    FichaResponseDTO obtenerPorId(Long id);
    FichaResponseDTO obtenerPorPacienteId(Long pacienteId);
    List<FichaResponseDTO> obtenerPorTerapeutaId(Long terapeutaId);
    FichaResponseDTO actualizar(Long id, FichaRequestDTO dto);
    FichaResponseDTO cerrar(Long id, CerrarFichaRequestDTO dto);
    void eliminar(Long id);
}

package ar.edu.centro8.ps.tif.config;

import ar.edu.centro8.ps.tif.model.Ficha;
import ar.edu.centro8.ps.tif.model.Paciente;
import ar.edu.centro8.ps.tif.model.Terapeuta;
import ar.edu.centro8.ps.tif.model.enums.EstadoFicha;
import ar.edu.centro8.ps.tif.repository.FichaRepository;
import ar.edu.centro8.ps.tif.repository.PacienteRepository;
import ar.edu.centro8.ps.tif.repository.TerapeutaRepository;
import lombok.RequiredArgsConstructor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import java.time.LocalDate;
import java.time.LocalDateTime;

/**
 * Componente de inicialización de datos (Data Loader / Seeder).
 * Se ejecuta al arrancar la aplicación y solo carga datos si las tablas están vacías,
 * para no duplicar registros en sucesivos reinicios.
 *
 * Los datos están pensados para probar las 4 reglas con la colección Bruno:
 *  - El terapeuta 1 queda con el cupo completo (3 fichas activas).
 *  - La ficha 3 tiene más de 180 días (etapa PROLONGADO).
 *  - La ficha 4 ya está CERRADA.
 *  - Los pacientes 4 y 6 quedan sin ficha.
 */
@Component
@RequiredArgsConstructor
public class DataLoader implements CommandLineRunner {

    private static final Logger log = LoggerFactory.getLogger(DataLoader.class);

    private final TerapeutaRepository terapeutaRepository;
    private final PacienteRepository pacienteRepository;
    private final FichaRepository fichaRepository;

    @Override
    public void run(String... args) {
        if (terapeutaRepository.count() > 0) {
            log.info("DataLoader: La base de datos ya contiene registros. Omitiendo precarga inicial.");
            return;
        }

        log.info("DataLoader: Base de datos vacía detectada. Iniciando precarga de datos de prueba...");

        // 1. Terapeutas
        Terapeuta t1 = terapeutaRepository.save(Terapeuta.builder()
                .nombre("Martín").apellido("Rossi").dni("30111222").matricula("MP-12345")
                .especialidad("Psicología clínica").telefono("1155667788")
                .email("martin.rossi@ejemplo.com").build());

        Terapeuta t2 = terapeutaRepository.save(Terapeuta.builder()
                .nombre("Valeria").apellido("Gómez").dni("29876543").matricula("MP-23456")
                .especialidad("Psiquiatría").telefono("1144332299")
                .email("valeria.gomez@ejemplo.com").build());

        terapeutaRepository.save(Terapeuta.builder()
                .nombre("Julián").apellido("Benítez").dni("34567890").matricula("MP-34567")
                .especialidad("Trabajo social").telefono("1133221155")
                .email("julian.benitez@ejemplo.com").build());
        log.info("DataLoader: 3 terapeutas guardados exitosamente.");

        // 2. Pacientes
        Paciente p1 = pacienteRepository.save(Paciente.builder()
                .nombre("Florencia").apellido("Alvarez").dni("35890123")
                .fechaNacimiento(LocalDate.of(1992, 8, 15)).telefono("1144332211")
                .email("florencia.alvarez@ejemplo.com").obraSocial("OSDE").build());

        Paciente p2 = pacienteRepository.save(Paciente.builder()
                .nombre("Esteban").apellido("Ríos").dni("31999888")
                .fechaNacimiento(LocalDate.of(1988, 3, 20)).telefono("1199887766")
                .email("esteban.rios@ejemplo.com").obraSocial("IOMA").build());

        Paciente p3 = pacienteRepository.save(Paciente.builder()
                .nombre("Mateo").apellido("López").dni("55123456")
                .fechaNacimiento(LocalDate.now().minusYears(15)).telefono("1166778899")
                .email("familia.lopez@ejemplo.com").obraSocial("Swiss Medical")
                .responsable("Marta López (madre)").build());

        pacienteRepository.save(Paciente.builder()
                .nombre("Camila").apellido("Sosa").dni("42111333")
                .fechaNacimiento(LocalDate.of(1999, 6, 2)).telefono("1122334455")
                .email("camila.sosa@ejemplo.com").build());

        Paciente p5 = pacienteRepository.save(Paciente.builder()
                .nombre("Lucas").apellido("Benítez").dni("27333444")
                .fechaNacimiento(LocalDate.of(1985, 12, 1)).telefono("1177889900")
                .email("lucas.benitez@ejemplo.com").obraSocial("PAMI").build());

        pacienteRepository.save(Paciente.builder()
                .nombre("Julieta").apellido("Fernández").dni("40555666")
                .fechaNacimiento(LocalDate.of(1995, 3, 12)).telefono("1155551234")
                .email("julieta.fernandez@ejemplo.com").build());
        log.info("DataLoader: 6 pacientes guardados exitosamente.");

        // 3. Fichas (distintas etapas para la regla del ResponseDTO)
        fichaRepository.save(Ficha.builder()
                .paciente(p1).terapeuta(t1)
                .fechaIngreso(LocalDate.now().minusDays(10))
                .motivoConsulta("Evaluación inicial")
                .diagnostico("En evaluación")
                .observaciones("Primera entrevista realizada.")
                .estado(EstadoFicha.ACTIVA).fechaCreacion(LocalDateTime.now()).build());

        fichaRepository.save(Ficha.builder()
                .paciente(p2).terapeuta(t1)
                .fechaIngreso(LocalDate.now().minusDays(90))
                .motivoConsulta("Seguimiento de tratamiento")
                .diagnostico("Tratamiento en curso")
                .observaciones("Asiste regularmente a las sesiones.")
                .estado(EstadoFicha.ACTIVA).fechaCreacion(LocalDateTime.now()).build());

        fichaRepository.save(Ficha.builder()
                .paciente(p3).terapeuta(t1)
                .fechaIngreso(LocalDate.now().minusDays(200))
                .motivoConsulta("Acompañamiento familiar")
                .diagnostico("Tratamiento prolongado")
                .observaciones("Se trabaja junto con la familia.")
                .estado(EstadoFicha.ACTIVA).fechaCreacion(LocalDateTime.now()).build());

        fichaRepository.save(Ficha.builder()
                .paciente(p5).terapeuta(t2)
                .fechaIngreso(LocalDate.now().minusDays(120))
                .motivoConsulta("Tratamiento ambulatorio")
                .diagnostico("Objetivos cumplidos")
                .estado(EstadoFicha.CERRADA)
                .fechaAlta(LocalDate.now().minusDays(20))
                .motivoAlta("Objetivos terapéuticos cumplidos")
                .fechaCreacion(LocalDateTime.now().minusDays(120)).build());
        log.info("DataLoader: 4 fichas guardadas exitosamente (3 activas del terapeuta 1 y 1 cerrada).");

        log.info("DataLoader: ¡Precarga inicial de datos completada con éxito!");
    }
}

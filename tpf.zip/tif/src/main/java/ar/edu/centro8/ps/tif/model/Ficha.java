package ar.edu.centro8.ps.tif.model;

import ar.edu.centro8.ps.tif.exception.DomainException;
import ar.edu.centro8.ps.tif.model.enums.EstadoFicha;
import jakarta.persistence.*;
import lombok.*;

import java.time.LocalDate;
import java.time.LocalDateTime;

/**
 * Ficha del paciente: una por paciente, a cargo de un terapeuta.
 */
@Entity
@Table(name = "fichas")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Ficha {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @OneToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "paciente_id", unique = true, nullable = false)
    private Paciente paciente;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "terapeuta_id", nullable = false)
    private Terapeuta terapeuta;

    @Column(name = "fecha_ingreso", nullable = false)
    private LocalDate fechaIngreso;

    @Column(name = "motivo_consulta", nullable = false, length = 255)
    private String motivoConsulta;

    @Column(length = 255)
    private String diagnostico;

    @Column(columnDefinition = "TEXT")
    private String observaciones;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false, length = 20)
    @Builder.Default
    private EstadoFicha estado = EstadoFicha.ACTIVA;

    @Column(name = "fecha_alta")
    private LocalDate fechaAlta;

    @Column(name = "motivo_alta", length = 255)
    private String motivoAlta;

    @Column(name = "fecha_creacion", nullable = false)
    private LocalDateTime fechaCreacion;

    @PrePersist
    protected void onCreate() {
        if (this.estado == null) {
            this.estado = EstadoFicha.ACTIVA;
        }
        if (this.fechaIngreso == null) {
            this.fechaIngreso = LocalDate.now();
        }
        if (this.fechaCreacion == null) {
            this.fechaCreacion = LocalDateTime.now();
        }
    }

    // =========================================================================
    // REGLA DE DOMINIO EN EL MODELO (ENTIDAD)
    // =========================================================================
    /**
     * Regla de dominio: controla el cierre (alta) de la ficha.
     * Una ficha solo puede cerrarse si está ACTIVA, con un motivo de alta obligatorio
     * y con una fecha de alta que no sea anterior al ingreso ni posterior a hoy.
     * La entidad protege sus propios invariantes: si se viola alguno, lanza DomainException.
     * Si no se informa fecha de alta, se toma la fecha actual.
     */
    public void cerrar(LocalDate fechaAlta, String motivo) {
        if (this.estado == EstadoFicha.CERRADA) {
            throw new DomainException("Regla de Dominio: La ficha ya se encuentra CERRADA.");
        }
        if (motivo == null || motivo.trim().isEmpty()) {
            throw new DomainException("Regla de Dominio: Debe proporcionarse obligatoriamente un motivo de alta para cerrar la ficha.");
        }
        LocalDate alta = (fechaAlta != null) ? fechaAlta : LocalDate.now();
        if (this.fechaIngreso != null && alta.isBefore(this.fechaIngreso)) {
            throw new DomainException("Regla de Dominio: La fecha de alta (" + alta + ") no puede ser anterior a la fecha de ingreso (" + this.fechaIngreso + ").");
        }
        if (alta.isAfter(LocalDate.now())) {
            throw new DomainException("Regla de Dominio: La fecha de alta no puede ser posterior a la fecha actual.");
        }
        this.estado = EstadoFicha.CERRADA;
        this.fechaAlta = alta;
        this.motivoAlta = motivo.trim();
    }
}

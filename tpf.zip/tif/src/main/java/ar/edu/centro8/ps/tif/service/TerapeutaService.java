package ar.edu.centro8.ps.tif.service;

import ar.edu.centro8.ps.tif.dto.request.TerapeutaRequestDTO;
import ar.edu.centro8.ps.tif.dto.response.TerapeutaResponseDTO;

import java.util.List;

public interface TerapeutaService {
    TerapeutaResponseDTO crear(TerapeutaRequestDTO dto);
    List<TerapeutaResponseDTO> obtenerTodos();
    TerapeutaResponseDTO obtenerPorId(Long id);
    TerapeutaResponseDTO actualizar(Long id, TerapeutaRequestDTO dto);
    void eliminar(Long id);
}

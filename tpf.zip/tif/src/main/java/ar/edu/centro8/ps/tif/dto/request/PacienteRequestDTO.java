package ar.edu.centro8.ps.tif.dto.request;

import jakarta.validation.constraints.*;
import lombok.*;

import java.time.LocalDate;
import java.time.Period;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class PacienteRequestDTO {

    private static final int MAYORIA_DE_EDAD = 18;

    @NotBlank(message = "El nombre del paciente es obligatorio")
    @Size(min = 2, max = 100, message = "El nombre debe tener entre 2 y 100 caracteres")
    private String nombre;

    @NotBlank(message = "El apellido del paciente es obligatorio")
    @Size(min = 2, max = 100, message = "El apellido debe tener entre 2 y 100 caracteres")
    private String apellido;

    @NotBlank(message = "El DNI es obligatorio")
    @Pattern(regexp = "^[0-9]{7,9}$", message = "El DNI debe contener entre 7 y 9 dígitos numéricos")
    private String dni;

    @NotNull(message = "La fecha de nacimiento es obligatoria")
    @Past(message = "La fecha de nacimiento debe ser una fecha pasada")
    private LocalDate fechaNacimiento;

    private String telefono;

    @NotBlank(message = "El correo electrónico es obligatorio")
    @Email(message = "Debe proporcionar una dirección de correo electrónico válida")
    private String email;

    @Size(max = 100, message = "La obra social no puede exceder los 100 caracteres")
    private String obraSocial;

    @Size(max = 150, message = "El responsable no puede exceder los 150 caracteres")
    private String responsable;

    // =========================================================================
    // REGLA DE NEGOCIO EN EL REQUEST DTO
    // =========================================================================
    /**
     * Regla de Negocio en RequestDTO:
     * Todo paciente menor de 18 años debe registrarse con una persona adulta
     * responsable (campo "responsable"). Para los mayores de edad el campo es opcional.
     * Se valida en la capa de entrada, antes de llegar al servicio.
     */
    @AssertTrue(message = "Regla de Negocio en RequestDTO: Los pacientes menores de 18 años deben informar un responsable adulto.")
    public boolean isResponsableInformadoSiEsMenor() {
        if (fechaNacimiento == null) {
            return true; // La obligatoriedad del campo la valida @NotNull
        }
        int edad = Period.between(fechaNacimiento, LocalDate.now()).getYears();
        if (edad >= MAYORIA_DE_EDAD) {
            return true;
        }
        return responsable != null && !responsable.trim().isEmpty();
    }
}

package ar.edu.centro8.ps.tif;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TifApplicationTests {

	@Test
	void contextLoads() {
	}

}

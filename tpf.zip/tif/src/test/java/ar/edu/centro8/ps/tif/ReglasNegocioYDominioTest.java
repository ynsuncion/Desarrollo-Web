package ar.edu.centro8.ps.tif;

import ar.edu.centro8.ps.tif.dto.request.FichaRequestDTO;
import ar.edu.centro8.ps.tif.dto.request.PacienteRequestDTO;
import ar.edu.centro8.ps.tif.dto.response.FichaResponseDTO;
import ar.edu.centro8.ps.tif.exception.BusinessException;
import ar.edu.centro8.ps.tif.exception.DomainException;
import ar.edu.centro8.ps.tif.model.Ficha;
import ar.edu.centro8.ps.tif.model.Paciente;
import ar.edu.centro8.ps.tif.model.Terapeuta;
import ar.edu.centro8.ps.tif.model.enums.EstadoFicha;
import ar.edu.centro8.ps.tif.repository.FichaRepository;
import ar.edu.centro8.ps.tif.repository.PacienteRepository;
import ar.edu.centro8.ps.tif.repository.TerapeutaRepository;
import ar.edu.centro8.ps.tif.service.impl.FichaServiceImpl;
import jakarta.validation.ConstraintViolation;
import jakarta.validation.Validation;
import jakarta.validation.Validator;
import jakarta.validation.ValidatorFactory;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.time.LocalDate;
import java.util.Optional;
import java.util.Set;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class ReglasNegocioYDominioTest {

    private Validator validator;

    @Mock
    private FichaRepository fichaRepository;

    @Mock
    private PacienteRepository pacienteRepository;

    @Mock
    private TerapeutaRepository terapeutaRepository;

    @InjectMocks
    private FichaServiceImpl fichaService;

    @BeforeEach
    void setUp() {
        ValidatorFactory factory = Validation.buildDefaultValidatorFactory();
        validator = factory.getValidator();
    }

    private PacienteRequestDTO pacienteConNacimiento(LocalDate nacimiento, String responsable) {
        return PacienteRequestDTO.builder()
                .nombre("Ana")
                .apellido("Sosa")
                .dni("40123456")
                .fechaNacimiento(nacimiento)
                .email("ana.sosa@ejemplo.com")
                .responsable(responsable)
                .build();
    }

    private Ficha fichaActiva(LocalDate ingreso) {
        return Ficha.builder()
                .id(1L)
                .estado(EstadoFicha.ACTIVA)
                .fechaIngreso(ingreso)
                .motivoConsulta("Evaluación inicial")
                .build();
    }

    // =========================================================================
    // 1. TEST: REGLA DE NEGOCIO EN EL REQUEST DTO
    // =========================================================================
    @Test
    @DisplayName("1.1 RequestDTO: Un paciente mayor de edad no necesita responsable")
    void testReglaNegocioRequestDTO_AdultoSinResponsable() {
        PacienteRequestDTO dto = pacienteConNacimiento(LocalDate.now().minusYears(30), null);

        Set<ConstraintViolation<PacienteRequestDTO>> violations = validator.validate(dto);
        assertTrue(violations.isEmpty(), "Un adulto sin responsable debe ser válido");
    }

    @Test
    @DisplayName("1.2 RequestDTO: Rechaza a un menor de edad sin responsable")
    void testReglaNegocioRequestDTO_MenorSinResponsableRechazado() {
        PacienteRequestDTO dto = pacienteConNacimiento(LocalDate.now().minusYears(12), "  ");

        Set<ConstraintViolation<PacienteRequestDTO>> violations = validator.validate(dto);
        assertFalse(violations.isEmpty(), "Debe fallar la validación para un menor sin responsable");
        assertTrue(violations.stream().anyMatch(v -> v.getMessage().contains("deben informar un responsable adulto")));
    }

    @Test
    @DisplayName("1.3 RequestDTO: Acepta a un menor de edad con responsable")
    void testReglaNegocioRequestDTO_MenorConResponsableValido() {
        PacienteRequestDTO dto = pacienteConNacimiento(LocalDate.now().minusYears(12), "Marta Sosa (madre)");

        Set<ConstraintViolation<PacienteRequestDTO>> violations = validator.validate(dto);
        assertTrue(violations.isEmpty(), "Un menor con responsable debe ser válido");
    }

    // =========================================================================
    // 2. TEST: REGLA DE NEGOCIO EN EL RESPONSE DTO
    // =========================================================================
    @Test
    @DisplayName("2.1 ResponseDTO: Ficha reciente queda en etapa INICIAL")
    void testReglaNegocioResponseDTO_EtapaInicial() {
        FichaResponseDTO response = FichaResponseDTO.fromEntity(fichaActiva(LocalDate.now().minusDays(10)));

        assertEquals(10L, response.getDiasEnTratamiento());
        assertEquals("INICIAL", response.getEtapaTratamiento());
        assertTrue(response.getAlertaSeguimiento().contains("evaluación inicial"));
    }

    @Test
    @DisplayName("2.2 ResponseDTO: Ficha de 200 días queda PROLONGADO y genera alerta")
    void testReglaNegocioResponseDTO_EtapaProlongada() {
        FichaResponseDTO response = FichaResponseDTO.fromEntity(fichaActiva(LocalDate.now().minusDays(200)));

        assertEquals(200L, response.getDiasEnTratamiento());
        assertEquals("PROLONGADO", response.getEtapaTratamiento());
        assertTrue(response.getAlertaSeguimiento().contains("tratamiento prolongado"));
    }

    @Test
    @DisplayName("2.3 ResponseDTO: Ficha cerrada queda FINALIZADO y cuenta los días hasta el alta")
    void testReglaNegocioResponseDTO_EtapaFinalizada() {
        Ficha ficha = fichaActiva(LocalDate.now().minusDays(100));
        ficha.cerrar(LocalDate.now().minusDays(40), "Objetivos cumplidos");

        FichaResponseDTO response = FichaResponseDTO.fromEntity(ficha);

        assertEquals(60L, response.getDiasEnTratamiento());
        assertEquals("FINALIZADO", response.getEtapaTratamiento());
        assertTrue(response.getAlertaSeguimiento().contains("Objetivos cumplidos"));
    }

    // =========================================================================
    // 3. TEST: REGLA DE DOMINIO EN LA ENTIDAD DEL MODELO
    // =========================================================================
    @Test
    @DisplayName("3.1 Regla Dominio Modelo: Cierre exitoso de una ficha activa")
    void testReglaDominioModelo_CerrarFichaExitoso() {
        Ficha ficha = fichaActiva(LocalDate.now().minusDays(30));
        LocalDate alta = LocalDate.now().minusDays(1);

        ficha.cerrar(alta, "Alta por cumplimiento de objetivos");

        assertEquals(EstadoFicha.CERRADA, ficha.getEstado());
        assertEquals(alta, ficha.getFechaAlta());
        assertEquals("Alta por cumplimiento de objetivos", ficha.getMotivoAlta());
    }

    @Test
    @DisplayName("3.2 Regla Dominio Modelo: Lanza DomainException al cerrar una ficha ya cerrada")
    void testReglaDominioModelo_CerrarFichaYaCerrada() {
        Ficha ficha = fichaActiva(LocalDate.now().minusDays(30));
        ficha.cerrar(null, "Primer cierre");

        DomainException ex = assertThrows(DomainException.class, () -> ficha.cerrar(null, "Segundo cierre"));
        assertTrue(ex.getMessage().contains("La ficha ya se encuentra CERRADA"));
    }

    @Test
    @DisplayName("3.3 Regla Dominio Modelo: Lanza DomainException si el alta es anterior al ingreso")
    void testReglaDominioModelo_AltaAnteriorAlIngreso() {
        Ficha ficha = fichaActiva(LocalDate.now().minusDays(10));

        DomainException ex = assertThrows(DomainException.class,
                () -> ficha.cerrar(LocalDate.now().minusDays(20), "Alta anterior al ingreso"));
        assertTrue(ex.getMessage().contains("no puede ser anterior a la fecha de ingreso"));
        assertEquals(EstadoFicha.ACTIVA, ficha.getEstado());
    }

    @Test
    @DisplayName("3.4 Regla Dominio Modelo: Lanza DomainException si el motivo de alta está vacío")
    void testReglaDominioModelo_CerrarSinMotivo() {
        Ficha ficha = fichaActiva(LocalDate.now().minusDays(10));

        DomainException ex = assertThrows(DomainException.class, () -> ficha.cerrar(null, "   "));
        assertTrue(ex.getMessage().contains("Debe proporcionarse obligatoriamente un motivo de alta"));
    }

    // =========================================================================
    // 4. TEST: ÚNICA REGLA DE NEGOCIO EN LA CAPA SERVICE
    // =========================================================================
    @Test
    @DisplayName("4.1 Regla Negocio Service: Rechaza la ficha si el terapeuta ya tiene el cupo completo")
    void testReglaNegocioService_CupoCompletoLanzaBusinessException() {
        Paciente paciente = Paciente.builder().id(2L).nombre("Ana").apellido("Sosa").build();
        Terapeuta terapeuta = Terapeuta.builder().id(1L).nombre("Martín").apellido("Rossi").build();

        when(pacienteRepository.findById(2L)).thenReturn(Optional.of(paciente));
        when(terapeutaRepository.findById(1L)).thenReturn(Optional.of(terapeuta));
        // Simulamos que el terapeuta ya tiene 3 fichas activas
        when(fichaRepository.countByTerapeutaIdAndEstado(1L, EstadoFicha.ACTIVA)).thenReturn(3L);

        FichaRequestDTO dto = FichaRequestDTO.builder()
                .pacienteId(2L)
                .terapeutaId(1L)
                .motivoConsulta("Evaluación inicial")
                .build();

        BusinessException ex = assertThrows(BusinessException.class, () -> fichaService.crear(dto));
        assertTrue(ex.getMessage().contains("Regla de Negocio (Service): El terapeuta ya tiene 3 fichas activas"));
    }

    @Test
    @DisplayName("4.2 Regla Negocio Service: Crea la ficha si el terapeuta todavía tiene cupo")
    void testReglaNegocioService_CupoDisponibleCreaFicha() {
        Paciente paciente = Paciente.builder().id(2L).nombre("Ana").apellido("Sosa").build();
        Terapeuta terapeuta = Terapeuta.builder().id(1L).nombre("Martín").apellido("Rossi").build();

        when(pacienteRepository.findById(2L)).thenReturn(Optional.of(paciente));
        when(terapeutaRepository.findById(1L)).thenReturn(Optional.of(terapeuta));
        when(fichaRepository.countByTerapeutaIdAndEstado(1L, EstadoFicha.ACTIVA)).thenReturn(2L);
        when(fichaRepository.save(any(Ficha.class))).thenAnswer(inv -> inv.getArgument(0));

        FichaRequestDTO dto = FichaRequestDTO.builder()
                .pacienteId(2L)
                .terapeutaId(1L)
                .motivoConsulta("Evaluación inicial")
                .build();

        FichaResponseDTO response = fichaService.crear(dto);

        assertEquals(EstadoFicha.ACTIVA, response.getEstado());
        assertEquals("INICIAL", response.getEtapaTratamiento());
    }
}

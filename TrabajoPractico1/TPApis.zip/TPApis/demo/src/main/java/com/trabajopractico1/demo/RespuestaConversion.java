package com.trabajopractico1.demo;

public class RespuestaConversion {

    private double galones;
    private double litros;

    public RespuestaConversion(double galones, double litros) {
        this.galones = galones;
        this.litros = litros;
    }

    public double getGalones() {
        return galones;
    }

    public double getLitros() {
        return litros;
    }
}
package com.trabajopractico1.demo.ejercicio1; 

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;


@RestController
public class GalonesController {

     private static final double FACTOR_CONVERSION = 3.78541;

     // endpoint http://localhost:8080/ejercicio1/galones-a-litros?galones=10
     
    @GetMapping("/ejercicio1/galones-a-litros")
    public RespuestaConversion convertirGalonesALitros(@RequestParam double galones) {
        double litros = galones * FACTOR_CONVERSION;
        return new RespuestaConversion(galones, litros);
    }


}
